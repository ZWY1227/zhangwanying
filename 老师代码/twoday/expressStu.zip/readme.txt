express  
    特快地  迅速地
    官网：https://www.expressjs.com.cn/
    基于 Node.js 平台，快速、开放、极简的 Web 开发框架

    说白了，它就是一个第三方模块，使用的话，需要安装：
        npm install express --save  产生依赖

    一般写项目都是基于框架进行开发。开发模式如下：
        原生开发： 一切从0开始  一行一行敲出项目   速度非常慢   兼容性
        框架开发： 毛坯房
            前端框架：vue  react 
            后端框架: express  koa  egg ...  
        二次开发：在已有的项目基础上进行开发  二手房
        



