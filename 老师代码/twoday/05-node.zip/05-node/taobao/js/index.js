let btn = document.getElementById("btn");
btn.onclick = function(){
    alert("登录成功~");
}