// 计算两个数和
function sum(a,b){
    return a+b;
}

// 第1个sum是导出去的名字  第2个sum是上面函数
exports.sum = sum;



