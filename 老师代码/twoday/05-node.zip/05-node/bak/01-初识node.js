/* 
快捷键：
    win + `  在vscode中打开终端
    cls  清屏  苍老师

插件：
    Code Runder  直接运行JS代码  是在NODE环境中运行

Node.js是什么？
    Node.js 是一个基于 Chrome V8 引擎的 JavaScript 运行时。
    V8引擎：谷歌浏览器中用于解析JS代码的引擎。 08年 大神把v8引擎移植到了node中。
    JavaScript 运行时：就是一个JS运行环境。 浏览器也是JS的运行环境。node不是一门语言，仅仅是一个运行JS代码的环境。

使用Node做什么？
    1）后面学习webpack构建工具就是基于node环境的。
    2）npm(node package manager) node包管理器  vue，react中就使用大量的包。 生态好。
    3）做HTTP服务器(web服务器/api服务器) 给前端提供API接口
    4）中间层
    5）服务端渲染（vue中的SSR） 等vue讲完后说~
    ... 

NODE特点：
    1）单线程（服务员）
    2）非阻塞I/O 
    3）事件驱动

安装NODE：
    安装完NODE，就可以提供一个运行JS代码的环境。并且，默认就把NPM安装了，不需要单独去安装NPM。
    一个Node安装包也就10几M，靠NPM，玩NODE，说白了就是玩各种第三方包。

    一路NEXT，安装OK。

    证明：win+R  ---->   cmd    在cmd窗口中输入node -v  如果出现版本号表示node安装OK~

 */

let a = 110;
console.log(a);








































